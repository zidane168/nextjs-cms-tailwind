import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'

const LearnImage: NextPage = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-2">
      <Head>
        <title> Learn Image Page </title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <footer className="flex h-24 w-full items-center justify-center border-t">
        <a
          className="flex items-center justify-center gap-2"
          href="https://vercel.com?utm_source=create-next-app&utm_medium=default-template&utm_campaign=create-next-app"
          target="_blank"
          rel="noopener noreferrer"
        >
          Powered by{' '}

          <div className="h-fit order-last md:order-first">
             <Image src="/images/monkey.png" alt="Monkey Logo" className="w-10 rounded-full"/>
          </div>
         
        </a>
      </footer>
    </div>
  )
}

export default LearnImage
