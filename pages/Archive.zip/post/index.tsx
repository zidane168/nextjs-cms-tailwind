import Head from 'next/head'

export default function Post() {
    return (
        <>
            <Head>
                <title> Post page </title>
                <link rel="icon" href="/favicon.ico" />
            </Head>

            <div className="menu columns-2 text-center flex flex-columns gap-2 p-2"> 
                <div className="flex-none w-1/3 p-2 bg-black text-white">
                    This is Post Page
                </div>

                <div className="flex-1 p-2 bg-black text-white">
                    This is Post Page
                </div>
            </div>
        </>
    )
}