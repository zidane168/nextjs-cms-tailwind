import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'
import Link from 'next/link'

const User: NextPage = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-2">
      <Head>
        <title> Welcome page </title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

        <div className="gap-4 columns-1 m-2 lg:columns-2 lg:m-4"> 
            <div className="shadow-lg founded p-4">
                <div className="flex space-x-2 items-center">  
                    {/*load local, client side rendering*/}
                    <Link href="/user">  
                      <p className="text-rose-800 hover:font-bold hover:cursor-pointer"> Go to User </p>
                    </Link>
                    <svg className="animate-spin w-6" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><title/><g data-name="1" id="_1"><path d="M72.86,407.49H69.13a15,15,0,0,1-15-15V282.25C54.13,201.62,119.74,136,200.37,136h50.21V70.75a15,15,0,0,1,25-11.14L451.18,217.88a15,15,0,0,1,0,22.28L275.63,398.44a15,15,0,0,1-25-11.15V322H183.65a99.52,99.52,0,0,0-96.28,74.25A15,15,0,0,1,72.86,407.49ZM183.65,292h81.93a15,15,0,0,1,15,15v46.54L418.73,229,280.58,104.47V151a15,15,0,0,1-15,15H200.37A116.37,116.37,0,0,0,84.13,282.25v56.36A129.6,129.6,0,0,1,183.65,292Z"/></g></svg>
                   
                </div>
                <p className="text-slate-500"> Find in-depth information about Next.js features and API </p> 
            </div>
        
            <div className="shadow-lg founded p-4">
                <div >   
                  <a href="/user" className="flex space-x-2 items-center">
                    <p className="text-indigo-700"> Go to User by a Element </p>
                    <svg className="animate-spin w-6" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><title/><g data-name="1" id="_1"><path d="M72.86,407.49H69.13a15,15,0,0,1-15-15V282.25C54.13,201.62,119.74,136,200.37,136h50.21V70.75a15,15,0,0,1,25-11.14L451.18,217.88a15,15,0,0,1,0,22.28L275.63,398.44a15,15,0,0,1-25-11.15V322H183.65a99.52,99.52,0,0,0-96.28,74.25A15,15,0,0,1,72.86,407.49ZM183.65,292h81.93a15,15,0,0,1,15,15v46.54L418.73,229,280.58,104.47V151a15,15,0,0,1-15,15H200.37A116.37,116.37,0,0,0,84.13,282.25v56.36A129.6,129.6,0,0,1,183.65,292Z"/></g></svg>
                  </a>
                </div>
                <p className="text-slate-500"> Find in-depth information about Next.js features and API </p> 
            </div>
        </div>
        
        <div className="gap-4 columns-1  lg:columns-2 lg:m-4"> 
            <div className="shadow-lg founded p-4">
                <div className="flex space-x-2 items-center">   
                    <p className="text-fuchsia-500"> Documentation </p>
                    <svg className="animate-spin w-6" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><title/><g data-name="1" id="_1"><path d="M72.86,407.49H69.13a15,15,0,0,1-15-15V282.25C54.13,201.62,119.74,136,200.37,136h50.21V70.75a15,15,0,0,1,25-11.14L451.18,217.88a15,15,0,0,1,0,22.28L275.63,398.44a15,15,0,0,1-25-11.15V322H183.65a99.52,99.52,0,0,0-96.28,74.25A15,15,0,0,1,72.86,407.49ZM183.65,292h81.93a15,15,0,0,1,15,15v46.54L418.73,229,280.58,104.47V151a15,15,0,0,1-15,15H200.37A116.37,116.37,0,0,0,84.13,282.25v56.36A129.6,129.6,0,0,1,183.65,292Z"/></g></svg>
                </div>
                <p className="text-slate-500"> Find in-depth information about Next.js features and API </p> 
            </div>
        
            <div className="shadow-lg founded p-4">
                <div className="flex space-x-2 items-center">   
                    <p className="text-vilh-blue"> Documentation </p>
                    <svg className="animate-spin w-6" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><title/><g data-name="1" id="_1"><path d="M72.86,407.49H69.13a15,15,0,0,1-15-15V282.25C54.13,201.62,119.74,136,200.37,136h50.21V70.75a15,15,0,0,1,25-11.14L451.18,217.88a15,15,0,0,1,0,22.28L275.63,398.44a15,15,0,0,1-25-11.15V322H183.65a99.52,99.52,0,0,0-96.28,74.25A15,15,0,0,1,72.86,407.49ZM183.65,292h81.93a15,15,0,0,1,15,15v46.54L418.73,229,280.58,104.47V151a15,15,0,0,1-15,15H200.37A116.37,116.37,0,0,0,84.13,282.25v56.36A129.6,129.6,0,0,1,183.65,292Z"/></g></svg>
                </div>
                <p className="text-slate-500"> Find in-depth information about Next.js features and API </p> 
            </div>
        </div>

      <footer className="flex h-24 w-full items-center justify-center border-t">
        <a
          className="flex items-center justify-center gap-2"
          href="https://vercel.com?utm_source=create-next-app&utm_medium=default-template&utm_campaign=create-next-app"
          target="_blank"
          rel="noopener noreferrer"
        >
          Powered by{' '} 
            {/* <Image src="/vercel.svg" alt="Vercel Logo" width={72} height={16}/>v */}
 
        </a>
      </footer>
    </div>
  )
}

export default User
